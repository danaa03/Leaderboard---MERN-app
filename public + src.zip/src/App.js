import './App.css';
import './components/leaderboard';
import Leaderboard from './components/leaderboard';

function App() {
  return (
    <div className="App">
      <Leaderboard/>
    </div>
  );
}

export default App;
