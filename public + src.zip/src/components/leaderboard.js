import React from 'react';
import './leaderboard.css'; 
import {useState, useEffect} from 'react';
import trophyGold from '../assets/trophy-gold.png'
import trophySilver from '../assets/trophy-silver.png'
import trophyBronze from '../assets/trophy-bronze.png'
import trophyGold2 from '../assets/trophy-gold-2.png'
import trophySilver2 from '../assets/trophy-silver-2.png'
import trophyBronze2 from '../assets/trophy-bronze-2.png'
import profileImage from '../assets/profile-image-default.avif'

function Leaderboard() {

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/viewSchema');
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        const sortedData=sortByScore(data);
        set_leaderboard_data(sortedData);
        console.log("Fetched users successfully... Leaderboard data: ", data);
      } catch (error) {
        console.error("Error while fetching data:", error);
      }
    };
    fetchData();
    const intervalId = setInterval(fetchData, 30000); // Polling interval: 300 seconds -> 5 mins
    return () => clearInterval(intervalId); // Cleanup interval on component unmount
  }, []);

  const [leaderboard_data, set_leaderboard_data] = useState([]);
  const [topThree, setIsTopThreeClicked] = useState(false);

  const handleTopThreeClick = () => {
    setIsTopThreeClicked(true);

  };


  return (
    <div className="container">
      {!topThree && (
        <div className='min-container'>
          <h2 className='mb-2'>Leaderboard</h2>
          <button type="button" className="btn btn-primary" onClick={handleTopThreeClick}>Top 3</button>
        </div>
      )}
      {topThree && (
        <div className="top-three-content">
          <h1 mb-3> GAME LEADERBOARD </h1>
          <DisplayTopThreeBoard leaderboard_data={leaderboard_data}/>
        </div>
      )}
      {(!topThree && leaderboard_data.length > 0) && (
        <table className="custom-table table-striped montserrat-sb">
          <thead>
            <tr>
              <th>RANK</th>
              <th> </th>
              <th>TEAM NAME</th>
              <th>TOTAL GAMES PLAYED</th>
              <th>SCORE</th>
            </tr>
          </thead>
          <tbody>
            {leaderboard_data.map((entry, index) => (
              <TableRow
                key={entry._id}
                entry={entry}
                rowIndex={index}
              />
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function DisplayTopThreeBoard({ leaderboard_data })
{
  const topData = [...leaderboard_data].filter(x=>x.rank ===1 || x.rank===2||x.rank===3);
  console.log(topData);
  return (
    <table className="custom-table-2 table-striped montserrat-sb">
          <tbody>
            {topData.map((entry, index) => (
              <TableRow2
                key={entry._id}
                entry={entry}
                rowIndex={index}
              />
            ))}
          </tbody>
      </table>
  )
}

function TableRow2({ entry, rowIndex }) {

  return (
    <tr>
      <td>
        {entry.rank === 1 && ( 
          <img src={trophyGold2} alt="Trophy Gold" className="trophy" />
        )}
        {entry.rank !== 1 && entry.rank !== 2 && entry.rank !== 3 && entry.rank}

        {entry.rank === 2 && (
          <img src ={trophySilver2} alt="Trophy Silver" className='trophy'/>
        )}

        {entry.rank === 3 && (
          <img src ={trophyBronze2} alt="Trophy Bronze" className='trophy'/>
        )}

      </td>
      <td style={{ width: '10px' }}>
          <img src = {profileImage} alt='profile display' className='profile-image'/>
      </td>
      <td>{entry.team}</td>
      <td>{entry.score}</td>
    </tr>
  );
}


function TableRow({ entry, rowIndex }) {
  const rowStyle = {
    backgroundColor: rowIndex % 2 === 0 ? 'rgb(255, 255, 255)' : 'rgb(236, 241, 248)',
  };

  return (
    <tr style={rowStyle}>
      <td>
        {entry.rank === 1 && ( 
          <img src={trophyGold} alt="Trophy Gold" className="trophy" />
        )}
        {entry.rank !== 1 && entry.rank !== 2 && entry.rank !== 3 && entry.rank}

        {entry.rank === 2 && (
          <img src ={trophySilver} alt="Trophy Silver" className='trophy'/>
        )}

        {entry.rank === 3 && (
          <img src ={trophyBronze} alt="Trophy Bronze" className='trophy'/>
        )}

      </td>
      <td>
          <img src = {profileImage} alt='profile display' className='profile-image'/>
      </td>
      <td>
        {entry.team}
      </td>
      <td>{entry.gamesPlayed}</td>
      <td>{entry.score}</td>
    </tr>
  );
}

function sortByScore(data)
{
    const sortedData = [...data].sort((a, b) => b.score - a.score);
    sortedData.forEach ((entry,index)=>{
      entry.rank = index+1;
    });
    return sortedData;
}

export default Leaderboard;
